// Copyright 2011 Google Inc. All Rights Reserved.
// Author: michaelsafyan@google.com (Michael Safyan)

#include "third_party/grte/catmlock.h"

#include <errno.h>
#include <sys/types.h>
#include <sys/mman.h>

// Internal layout of *nl_catd (i.e. catalog_info) as defined in:
// gcctools/vendor_src/glibc/eglibc-2.11.1/catgets/catgetsinfo.h
typedef struct {
  enum { mmapped, malloced } status;

  size_t plane_size;
  size_t plane_depth;
  u_int32_t* name_ptr;
  const char* strings;

  void* file_ptr;
  size_t file_size;
} nl_catd_internal_layout;

int catmlock(nl_catd catalog) {
  if (!catalog || (catalog == ((nl_catd) -1))) {
    errno = EINVAL;
    return -1;
  }

  // Read a single message to force the catalog to be memory mapped.
  catgets(catalog, 1, 1, 0);

  nl_catd_internal_layout* layout = ((nl_catd_internal_layout*) catalog);
  return mlock(layout->file_ptr, layout->file_size);
}

int catmunlock(nl_catd catalog) {
  if (!catalog || (catalog == ((nl_catd) -1))) {
    errno = EINVAL;
    return -1;
  }

  nl_catd_internal_layout* layout = ((nl_catd_internal_layout*) catalog);
  return munlock(layout->file_ptr, layout->file_size);
}
