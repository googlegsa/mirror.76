// Copyright 2011 Google Inc. All Rights Reserved.
// Author: michaelsafyan@google.com (Michael Safyan)

#ifndef THIRD_PARTY_GRTE_CATMLOCK_H_
#define THIRD_PARTY_GRTE_CATMLOCK_H_

#include <nl_types.h>

#ifdef __cplusplus
extern "C" {
#endif

// Attempts to mlock the specified catalog, returns 0 on success,
// and has the same error semantics as mlock.
int catmlock(nl_catd catalog);

// Attempts to munlock the specified catalog, returns 0 on success,
// and has the same error semantics as munlock.
int catmunlock(nl_catd catalog);

#ifdef __cplusplus
} // extern "C"
#endif

#endif  // THIRD_PARTY_GRTE_CATMLOCK_H_
